package collage;

import java.util.ArrayList;
import java.util.List;

public class Mark {

	private String subjectName;
	private int mark;

	
//----------------------- seters and geters-------------------------	
		
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public int getMark() {
		return mark;
	}
	public void setMark(int mark) {
		this.mark = mark;
	}
	
	//------------------ class methods-------------------
	 double getGpa(List<Mark> glist) {
		double total=0;
		for(Mark mark:glist) {
			total=total+(double)(mark.getMark());
		}
		return total/glist.size();
	}
}

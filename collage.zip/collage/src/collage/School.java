package collage;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class School {

	private String location;
	private int phoneNumber;
	
	private ArrayList<Department> departmentList = new ArrayList<>();
School(){System.out.println("do you want to create school system y/n");}
	//----------------------- seters and geters-------------------------

	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public ArrayList<Department> getDepartmentList() {
		return departmentList;
	}
	public void setDepartmentList(ArrayList<Department> departmentList) {
		this.departmentList = departmentList;
	}

	static void history(Stack stk){
		for(int i=0;i<=stk.size();i++) {
		System.out.println(format.red +stk.pop());
	}}
	
	}




package collage;

public class format {
	
	format(){
		System.out.println("here we create school system");
		 Error e = new Error("Error have been defined manually");
	System.out.println(e.getMessage());
	}
	public static final String rest = "\u001B[0m";
	public static final String black = "\u001B[30m";
	public static final String red = "\u001B[31m";
	public static final String green = "\u001B[32m";
	public static final String yellow = "\u001B[33m";
	public static final String blue = "\u001B[34m";
	public static final String purpple = "\u001B[35m";
	public static final String cyan = "\u001B[36m";
	public static final String white = "\u001B[37m";
	
	
}

/**
 * 
 */
/**
 * @author Lenovo
 *
 */
module collage {
}